// XHTTP relay for Xray/V2Ray — runs on Vercel Node runtime.
// Mounted under /api/relay/* so it doesn't clash with the website's routes.
// Configure your Xray client to use path: /api/relay/<your-uuid-or-secret>

import { Readable } from "node:stream";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const TARGET_BASE = (process.env.TARGET_DOMAIN || "").replace(/\/$/, "");

const STRIP_HEADERS = new Set([
  "host", "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
  "te", "trailer", "transfer-encoding", "upgrade",
  "forwarded", "x-forwarded-host", "x-forwarded-proto", "x-forwarded-port",
  "content-length"
]);

async function relay(req, { params }) {
  if (!TARGET_BASE) {
    return new Response("Misconfigured: TARGET_DOMAIN is not set", { status: 500 });
  }

  try {
    // Reconstruct the original upstream path. The Xray client connects to
    // /api/relay/<their-path>, but the upstream expects /<their-path>.
    const segments = (params?.path || []);
    const subPath = segments.length ? "/" + segments.map(encodeURIComponent).join("/") : "/";
    const url = new URL(req.url);
    const targetUrl = TARGET_BASE + subPath + url.search;

    const headers = {};
    let clientIp = null;
    for (const [key, value] of req.headers.entries()) {
      const k = key.toLowerCase();
      if (STRIP_HEADERS.has(k)) continue;
      if (k.startsWith("x-vercel-")) continue;
      if (k === "x-real-ip") { clientIp = value; continue; }
      if (k === "x-forwarded-for") { if (!clientIp) clientIp = value; continue; }
      headers[k] = value;
    }
    if (clientIp) headers["x-forwarded-for"] = clientIp;

    const method = req.method;
    const hasBody = method !== "GET" && method !== "HEAD";

    const fetchOpts = { method, headers, redirect: "manual" };
    if (hasBody) {
      fetchOpts.body = req.body;
      fetchOpts.duplex = "half";
    }

    const upstream = await fetch(targetUrl, fetchOpts);

    const respHeaders = new Headers();
    for (const [k, v] of upstream.headers) {
      if (k.toLowerCase() === "transfer-encoding") continue;
      respHeaders.set(k, v);
    }

    return new Response(upstream.body, { status: upstream.status, headers: respHeaders });
  } catch (err) {
    console.error("relay error:", err);
    return new Response("Bad Gateway: Tunnel Failed", { status: 502 });
  }
}

export const GET = relay;
export const POST = relay;
export const PUT = relay;
export const DELETE = relay;
export const PATCH = relay;
export const HEAD = relay;
export const OPTIONS = relay;
