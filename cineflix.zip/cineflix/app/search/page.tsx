import { search } from "@/lib/tmdb";
import PosterCard from "@/components/PosterCard";

export const dynamic = "force-dynamic";

export default async function SearchPage({ searchParams }: { searchParams: { q?: string } }) {
  const q = (searchParams.q || "").trim();
  const results = q ? await search(q).catch(() => []) : [];
  const filtered = results.filter(r => r.media_type === "movie" || r.media_type === "tv");
  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-2">Search Results</h1>
      <p className="text-muted mb-8">{q ? `Showing results for "${q}"` : "Type a query in the search bar above."}</p>
      {filtered.length === 0 && q && <p className="text-muted">No results found.</p>}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {filtered.map(it => <PosterCard key={`${it.id}-${it.media_type}`} item={it} />)}
      </div>
    </div>
  );
}
