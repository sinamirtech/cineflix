import { notFound } from "next/navigation";
import { discover, getGenres, MediaType } from "@/lib/tmdb";
import PosterCard from "@/components/PosterCard";
import Link from "next/link";

export const revalidate = 3600;

export default async function CategoryPage({ params, searchParams }: { params: { type: string }; searchParams: { genre?: string } }) {
  const type = params.type as MediaType;
  if (type !== "movie" && type !== "tv") notFound();
  const [items, genres] = await Promise.all([
    discover(type, searchParams.genre).catch(() => []),
    getGenres(type).catch(() => [])
  ]);
  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-6">{type === "movie" ? "Movies" : "TV Shows"}</h1>
      <div className="flex flex-wrap gap-2 mb-8">
        <Link href={`/category/${type}`} className={`px-4 py-1.5 rounded-full text-sm ${!searchParams.genre ? "bg-accent" : "bg-white/10 hover:bg-white/20"}`}>All</Link>
        {genres.map(g => (
          <Link key={g.id} href={`/category/${type}?genre=${g.id}`} className={`px-4 py-1.5 rounded-full text-sm ${String(g.id) === searchParams.genre ? "bg-accent" : "bg-white/10 hover:bg-white/20"}`}>{g.name}</Link>
        ))}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {items.map(it => <PosterCard key={it.id} item={it} type={type} />)}
      </div>
    </div>
  );
}
