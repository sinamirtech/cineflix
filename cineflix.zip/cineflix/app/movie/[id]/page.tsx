import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { IMG, getMovieDetails, externalLinks } from "@/lib/tmdb";
import PosterCard from "@/components/PosterCard";
import type { Metadata } from "next";

export const revalidate = 3600;

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  try {
    const m = await getMovieDetails(params.id);
    return {
      title: m.title,
      description: m.overview?.slice(0, 160),
      openGraph: { title: m.title, description: m.overview, images: [IMG(m.backdrop_path, "w780")] }
    };
  } catch { return { title: "Movie" }; }
}

export default async function MoviePage({ params }: { params: { id: string } }) {
  let movie: any;
  try { movie = await getMovieDetails(params.id); } catch { notFound(); }
  const links = externalLinks(movie, "movie");
  const cast = movie.credits?.cast?.slice(0, 10) || [];
  const similar = movie.similar?.results || [];
  return (
    <>
      <section className="relative h-[60vh] min-h-[400px]">
        <Image src={IMG(movie.backdrop_path, "original")} alt={movie.title} fill priority className="object-cover" sizes="100vw" />
        <div className="absolute inset-0 hero-gradient" />
      </section>
      <div className="max-w-7xl mx-auto px-4 -mt-40 relative z-10">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="flex-none w-48 md:w-64 mx-auto md:mx-0">
            <div className="relative aspect-[2/3] rounded-xl overflow-hidden shadow-2xl">
              <Image src={IMG(movie.poster_path, "w500")} alt={movie.title} fill sizes="256px" className="object-cover" />
            </div>
          </div>
          <div className="flex-1">
            <h1 className="text-3xl md:text-5xl font-extrabold">{movie.title}</h1>
            {movie.tagline && <p className="text-muted italic mt-2">{movie.tagline}</p>}
            <div className="flex flex-wrap gap-3 mt-4 text-sm">
              <span className="bg-yellow-500/20 text-yellow-400 px-3 py-1 rounded-full font-semibold">★ {movie.vote_average?.toFixed(1)}</span>
              <span className="bg-white/10 px-3 py-1 rounded-full">{movie.release_date?.slice(0, 4)}</span>
              <span className="bg-white/10 px-3 py-1 rounded-full">{movie.runtime} min</span>
              {movie.genres?.map((g: any) => <span key={g.id} className="bg-white/10 px-3 py-1 rounded-full">{g.name}</span>)}
            </div>
            <p className="mt-5 text-white/80 leading-relaxed">{movie.overview}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href={links.googleWatch} target="_blank" rel="noopener" className="bg-accent hover:bg-accent2 px-6 py-3 rounded-full font-semibold text-sm">▶ Watch Online</a>
              <a href={links.googleDownload} target="_blank" rel="noopener" className="bg-white/10 hover:bg-white/20 px-6 py-3 rounded-full font-semibold text-sm">⬇ Download</a>
              <a href={links.youtubeTrailer} target="_blank" rel="noopener" className="bg-white/10 hover:bg-white/20 px-6 py-3 rounded-full font-semibold text-sm">🎬 Trailer</a>
              <a href={links.imdb} target="_blank" rel="noopener" className="bg-yellow-500/90 hover:bg-yellow-500 text-black px-6 py-3 rounded-full font-semibold text-sm">IMDb</a>
            </div>
          </div>
        </div>
        {cast.length > 0 && (
          <section className="mt-12">
            <h2 className="text-2xl font-bold mb-4">Top Cast</h2>
            <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
              {cast.map((c: any) => (
                <div key={c.id} className="flex-none w-32 text-center">
                  <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-panel">
                    <Image src={IMG(c.profile_path, "w300")} alt={c.name} fill sizes="128px" className="object-cover" />
                  </div>
                  <p className="text-sm font-semibold mt-2 line-clamp-1">{c.name}</p>
                  <p className="text-xs text-muted line-clamp-1">{c.character}</p>
                </div>
              ))}
            </div>
          </section>
        )}
        {similar.length > 0 && (
          <section className="mt-12 mb-12">
            <h2 className="text-2xl font-bold mb-4">You May Also Like</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {similar.slice(0, 12).map((s: any) => <PosterCard key={s.id} item={s} type="movie" />)}
            </div>
          </section>
        )}
      </div>
    </>
  );
}
